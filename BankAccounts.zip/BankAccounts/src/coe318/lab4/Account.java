/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe318.lab4;

/**
 *
 * @author edmond
 */
public class Account {
    private String name;
    private int number;
    double balance;
    
    public Account(String name, int number, double initialBalance) {
        this.name = name;
        this.number = number;
        this.balance = initialBalance;
    }
    
    public String getName() {
        return name;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public int getNumber() {
        return number;
    }
    
    public boolean deposit(double amount) {
        balance += amount;
        return true;
    }
    
    public boolean withdraw(double amount) {
        if (amount > balance) {
            return false;
        }
        else {
            balance -= amount;
            return true;
        }
    }
    
    @Override
    public String toString() {//DO NOT MODIFY
        return "(" + getName() + ", " + getNumber() + ", " +
        String.format("$%.2f", getBalance()) + ")";
    }
}
