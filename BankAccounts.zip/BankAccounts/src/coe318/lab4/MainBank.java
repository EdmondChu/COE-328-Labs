/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe318.lab4;

/**
 *
 * @author edmond
 */
public class MainBank {
    public static void main(String[]args) {
        int doraAccountNum = 447;
        Bank tD = new Bank("Toronto Dominion", 3);
        Bank bMO = new Bank("Bank of Montreal", 5);
        
        System.out.println(tD.toString());
        
        tD.add(new Account("Charles",234,200));
        System.out.println(tD.toString());
        
        System.out.println("td has account # " + doraAccountNum + ": "+tD.hasAccountNumber(doraAccountNum));
        if(!tD.hasAccountNumber(doraAccountNum)) {
            tD.add(new Account("Dora",doraAccountNum,300));
        }
        System.out.println(tD.toString());
        
        bMO.add(new Account("Edward",456,400));
        System.out.println(bMO.toString());
        
        
       //TODO: Inform TA that the lab is written incorrectly
    }
}
