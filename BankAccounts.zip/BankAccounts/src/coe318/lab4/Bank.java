/**
 *
 * @author edmond
 */
package coe318.lab4;

public class Bank {
    private String name;
    private Account [] accounts;
    private int numAccounts;

    public Bank(String name, int maxNumberAccounts) {
        this.name = name;
        accounts = new Account[maxNumberAccounts];
        numAccounts = 0;
    }
    
    public String getName() {
        return name;
    }

    public int getNumAccounts() {
        int accountsOpen = 0;
        for (Account account : accounts) {
            if (account != null) {
                accountsOpen++;
            }
        }
        return accountsOpen;
    }


    public Account[] getAccounts() {
        return accounts;
    }

    /**
     * Return true if the Bank already has an account
     * with this number; otherwise false.
     * @param accountNumber
     * @return
     */
    public boolean hasAccountNumber(int accountNumber) {
        
        try {
                for( Account num : accounts) {
                if (num.getNumber() == accountNumber) {
                    return true;
                }
            }
        } catch (NullPointerException e) {
            return false;
        }
        return false;
    }

    /**
     * Adds the specified account to the Bank if possible. 
     * If the account number already exists or the Bank has reached its maximum
     * number of accounts, return false and do not add it; otherwise,
     * add it and return true.
     * @param account
     * @return true if successful
     */
    public boolean add(Account account) {
        for (int i = 0; i < accounts.length; i++){
            if (accounts[i] == null) {
                accounts[i] = account;
                return true;
            }
        } 
        return false;
    }

    @Override
    public String toString() {
        //DO NOT MODIFY THIS CODE
        String s = getName() + ": " + getNumAccounts() +
                " of " + getAccounts().length +
                " accounts open";
        for(Account account : getAccounts()) {
            if (account == null) break;
            s += "\n  " + account;
        }
        return s;
    }
}